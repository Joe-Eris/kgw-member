CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS members (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), member_no text UNIQUE NOT NULL, full_name text NOT NULL,
 email text, phone text, gender text, date_of_birth date, address text, marital_status text, occupation text,
 joined_at date DEFAULT CURRENT_DATE, status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','inactive','exited')),
 profile_photo_url text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), email text UNIQUE NOT NULL, phone text, password_hash text NOT NULL,
 member_id uuid REFERENCES members(id) ON DELETE SET NULL, status text NOT NULL DEFAULT 'active', created_at timestamptz DEFAULT now(), last_login_at timestamptz
);
CREATE TABLE IF NOT EXISTS roles(id serial PRIMARY KEY, code text UNIQUE NOT NULL, name text NOT NULL);
CREATE TABLE IF NOT EXISTS user_roles(user_id uuid REFERENCES users(id) ON DELETE CASCADE, role_id int REFERENCES roles(id) ON DELETE CASCADE, PRIMARY KEY(user_id,role_id));
CREATE TABLE IF NOT EXISTS sessions(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid REFERENCES users(id) ON DELETE CASCADE, token_hash text UNIQUE NOT NULL, csrf_token text NOT NULL, expires_at timestamptz NOT NULL, created_at timestamptz DEFAULT now());

CREATE TABLE IF NOT EXISTS departments(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text UNIQUE NOT NULL, slug text UNIQUE NOT NULL, type text DEFAULT 'department', active boolean DEFAULT true, created_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS member_departments(member_id uuid REFERENCES members(id) ON DELETE CASCADE, department_id uuid REFERENCES departments(id) ON DELETE CASCADE, is_primary boolean DEFAULT false, joined_at date DEFAULT CURRENT_DATE, PRIMARY KEY(member_id,department_id));
CREATE TABLE IF NOT EXISTS member_guardians(child_member_id uuid REFERENCES members(id) ON DELETE CASCADE, guardian_member_id uuid REFERENCES members(id) ON DELETE CASCADE, relationship text NOT NULL, PRIMARY KEY(child_member_id,guardian_member_id));

CREATE TABLE IF NOT EXISTS funds(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text UNIQUE NOT NULL, code text UNIQUE NOT NULL, department_id uuid REFERENCES departments(id) ON DELETE SET NULL, active boolean DEFAULT true);
CREATE TABLE IF NOT EXISTS contribution_types(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, code text UNIQUE NOT NULL, department_id uuid REFERENCES departments(id) ON DELETE SET NULL, fund_id uuid REFERENCES funds(id) ON DELETE SET NULL, amount numeric(14,2), frequency text DEFAULT 'once', required boolean DEFAULT false, active boolean DEFAULT true);
CREATE TABLE IF NOT EXISTS obligations(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), member_id uuid REFERENCES members(id) ON DELETE CASCADE, contribution_type_id uuid REFERENCES contribution_types(id) ON DELETE CASCADE, period_key text NOT NULL, amount_due numeric(14,2) NOT NULL, amount_paid numeric(14,2) NOT NULL DEFAULT 0, due_date date, status text NOT NULL DEFAULT 'outstanding', UNIQUE(member_id,contribution_type_id,period_key));
CREATE TABLE IF NOT EXISTS payments(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), receipt_no text UNIQUE NOT NULL, member_id uuid REFERENCES members(id) ON DELETE SET NULL, payer_name text, provider text NOT NULL, provider_transaction_id text, provider_ref text, amount numeric(14,2) NOT NULL, currency text NOT NULL DEFAULT 'NGN', status text NOT NULL DEFAULT 'pending', paid_at timestamptz, created_by uuid REFERENCES users(id) ON DELETE SET NULL, raw jsonb, created_at timestamptz DEFAULT now());
CREATE UNIQUE INDEX IF NOT EXISTS payments_provider_tx_unique ON payments(provider,provider_transaction_id) WHERE provider_transaction_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS payment_allocations(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), payment_id uuid REFERENCES payments(id) ON DELETE CASCADE, obligation_id uuid REFERENCES obligations(id) ON DELETE SET NULL, contribution_type_id uuid REFERENCES contribution_types(id) ON DELETE SET NULL, fund_id uuid REFERENCES funds(id) ON DELETE SET NULL, amount numeric(14,2) NOT NULL);
CREATE TABLE IF NOT EXISTS pledges(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), member_id uuid REFERENCES members(id) ON DELETE CASCADE, contribution_type_id uuid REFERENCES contribution_types(id) ON DELETE SET NULL, title text NOT NULL, amount_pledged numeric(14,2) NOT NULL, amount_paid numeric(14,2) DEFAULT 0, due_date date, status text DEFAULT 'active', created_at timestamptz DEFAULT now());

CREATE TABLE IF NOT EXISTS expenses(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), reference text UNIQUE NOT NULL, department_id uuid REFERENCES departments(id) ON DELETE SET NULL, fund_id uuid REFERENCES funds(id) ON DELETE SET NULL, category text NOT NULL, description text NOT NULL, amount numeric(14,2) NOT NULL, status text DEFAULT 'draft', requested_by uuid REFERENCES users(id) ON DELETE SET NULL, approved_by uuid REFERENCES users(id) ON DELETE SET NULL, approved_at timestamptz, receipt_url text, created_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS events(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), title text NOT NULL, description text, starts_at timestamptz NOT NULL, ends_at timestamptz, location text, visibility text DEFAULT 'public', active boolean DEFAULT true, created_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS attendance(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), member_id uuid REFERENCES members(id) ON DELETE CASCADE, event_id uuid REFERENCES events(id) ON DELETE SET NULL, attended_at timestamptz DEFAULT now(), source text DEFAULT 'manual');
CREATE TABLE IF NOT EXISTS counselling_cases(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), member_id uuid REFERENCES members(id) ON DELETE CASCADE, assigned_to uuid REFERENCES users(id) ON DELETE SET NULL, status text DEFAULT 'open', opened_at timestamptz DEFAULT now(), closed_at timestamptz);
CREATE TABLE IF NOT EXISTS counselling_notes(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), case_id uuid REFERENCES counselling_cases(id) ON DELETE CASCADE, author_id uuid REFERENCES users(id) ON DELETE SET NULL, note text NOT NULL, created_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS volunteer_shifts(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), department_id uuid REFERENCES departments(id) ON DELETE SET NULL, event_id uuid REFERENCES events(id) ON DELETE CASCADE, title text NOT NULL, starts_at timestamptz NOT NULL, ends_at timestamptz);
CREATE TABLE IF NOT EXISTS volunteer_assignments(shift_id uuid REFERENCES volunteer_shifts(id) ON DELETE CASCADE, member_id uuid REFERENCES members(id) ON DELETE CASCADE, status text DEFAULT 'assigned', PRIMARY KEY(shift_id,member_id));

CREATE TABLE IF NOT EXISTS media_items(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), slug text UNIQUE NOT NULL, title text NOT NULL, description text, speaker text, service_date date, category text, youtube_id text, source_file_path text, stream_url text, download_url text, audio_url text, thumbnail_url text, status text DEFAULT 'draft', published_at timestamptz, created_by uuid REFERENCES users(id) ON DELETE SET NULL, created_at timestamptz DEFAULT now(), updated_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS contact_messages(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, email text, phone text, subject text, message text NOT NULL, status text DEFAULT 'new', created_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS notifications(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid REFERENCES users(id) ON DELETE CASCADE, title text NOT NULL, body text NOT NULL, read_at timestamptz, created_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS settings(key text PRIMARY KEY, value jsonb NOT NULL, updated_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS oauth_tokens(provider text PRIMARY KEY, encrypted_value text NOT NULL, updated_at timestamptz DEFAULT now());
CREATE TABLE IF NOT EXISTS audit_logs(id bigserial PRIMARY KEY, actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL, action text NOT NULL, entity_type text NOT NULL, entity_id text, before_data jsonb, after_data jsonb, ip text, created_at timestamptz DEFAULT now());


CREATE TABLE IF NOT EXISTS member_milestones(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), member_id uuid REFERENCES members(id) ON DELETE CASCADE,
 type text NOT NULL CHECK(type IN ('new_convert','baptism','confirmation','other')), occurred_on date NOT NULL DEFAULT CURRENT_DATE,
 notes text, created_by uuid REFERENCES users(id) ON DELETE SET NULL, created_at timestamptz DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cell_groups(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text UNIQUE NOT NULL, leader_member_id uuid REFERENCES members(id) ON DELETE SET NULL,
 meeting_location text, active boolean DEFAULT true, created_at timestamptz DEFAULT now()
);
CREATE TABLE IF NOT EXISTS cell_group_members(
 cell_group_id uuid REFERENCES cell_groups(id) ON DELETE CASCADE, member_id uuid REFERENCES members(id) ON DELETE CASCADE,
 joined_at date DEFAULT CURRENT_DATE, PRIMARY KEY(cell_group_id,member_id)
);
CREATE TABLE IF NOT EXISTS membership_tokens(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), member_id uuid REFERENCES members(id) ON DELETE CASCADE,
 token_hash text UNIQUE NOT NULL, token_hint text, active boolean DEFAULT true, issued_at timestamptz DEFAULT now(), revoked_at timestamptz
);
